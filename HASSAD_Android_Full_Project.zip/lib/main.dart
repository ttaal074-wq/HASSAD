import 'package:flutter/material.dart';

void main() => runApp(const HassadApp());

const green = Color(0xFF176B45);
const lime = Color(0xFFE7F3D6);
const ink = Color(0xFF17352A);

class HassadApp extends StatelessWidget {
  const HassadApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'حصاد HASSAD',
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: green),
      scaffoldBackgroundColor: const Color(0xFFF7F9F4),
      fontFamily: 'Arial',
    ),
    home: const MarketScreen(),
  );
}

class Product {
  Product(this.name, this.farm, this.price, this.unit, this.emoji, this.category);
  final String name, farm, unit, emoji, category;
  final double price;
}

class MarketScreen extends StatefulWidget {
  const MarketScreen({super.key});
  @override
  State<MarketScreen> createState() => _MarketScreenState();
}

class _MarketScreenState extends State<MarketScreen> {
  int tab = 0;
  String category = 'الكل';
  final search = TextEditingController();
  final cart = <Product, int>{};
  final products = <Product>[
    Product('طماطم بلدي', 'مزرعة النور', 18, 'كيلو', '🍅', 'خضروات'),
    Product('بطاطس جديدة', 'أرض الخير', 14, 'كيلو', '🥔', 'خضروات'),
    Product('برتقال سكري', 'مزارع الوادي', 25, 'كيلو', '🍊', 'فاكهة'),
    Product('خيار طازج', 'مزرعة الندى', 16, 'كيلو', '🥒', 'خضروات'),
    Product('مانجو', 'مزارع الإسماعيلية', 42, 'كيلو', '🥭', 'فاكهة'),
    Product('فلفل أخضر', 'أرض الخير', 20, 'كيلو', '🫑', 'خضروات'),
  ];

  List<Product> get shown => products.where((p) =>
    (category == 'الكل' || p.category == category) &&
    (p.name.contains(search.text) || p.farm.contains(search.text))).toList();

  double get total => cart.entries.fold(0, (sum, e) => sum + e.key.price * e.value);

  @override
  void dispose() {
    search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Row(children: [
          Text('🌱', style: TextStyle(fontSize: 25)),
          SizedBox(width: 8),
          Text('حصاد', style: TextStyle(color: green, fontWeight: FontWeight.w900)),
          SizedBox(width: 5),
          Text('HASSAD', style: TextStyle(color: ink, fontSize: 13, letterSpacing: 1.4)),
        ]),
        actions: [
          IconButton(
            onPressed: () => setState(() => tab = 2),
            icon: Badge(
              label: Text('${cart.values.fold<int>(0, (a, b) => a + b)}'),
              child: const Icon(Icons.shopping_bag_outlined),
            ),
          ),
          const SizedBox(width: 6),
        ],
      ),
      body: tab == 0 ? marketBody() : tab == 1 ? farmerBody() : cartBody(),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.storefront_outlined), selectedIcon: Icon(Icons.storefront), label: 'السوق'),
          NavigationDestination(icon: Icon(Icons.agriculture_outlined), selectedIcon: Icon(Icons.agriculture), label: 'المزارع'),
          NavigationDestination(icon: Icon(Icons.shopping_cart_outlined), selectedIcon: Icon(Icons.shopping_cart), label: 'السلة'),
        ],
      ),
    ),
  );

  Widget marketBody() => ListView(padding: const EdgeInsets.all(16), children: [
    Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [green, Color(0xFF2D9364)]),
        borderRadius: BorderRadius.circular(24),
      ),
      child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('من أرض الخير إلى كل بيت', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.bold)),
        SizedBox(height: 8),
        Text('منتجات طازجة مباشرة من المزارع', style: TextStyle(color: Colors.white70)),
        SizedBox(height: 15),
        Text('جودة • ط freshness • أسعار عادلة', style: TextStyle(color: Colors.white)),
      ]),
    ),
    const SizedBox(height: 16),
    TextField(
      controller: search,
      onChanged: (_) => setState(() {}),
      decoration: InputDecoration(
        hintText: 'ابحث عن منتج أو مزرعة...',
        prefixIcon: const Icon(Icons.search),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
      ),
    ),
    const SizedBox(height: 12),
    Wrap(
      spacing: 8,
      children: ['الكل', 'خضروات', 'فاكهة'].map((c) => ChoiceChip(
        label: Text(c),
        selected: category == c,
        onSelected: (_) => setState(() => category = c),
      )).toList(),
    ),
    const SizedBox(height: 14),
    GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: shown.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: .72,
      ),
      itemBuilder: (_, i) => productCard(shown[i]),
    ),
  ]);

  Widget productCard(Product p) => Container(
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20),
      border: Border.all(color: const Color(0xFFE8EEE4))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Expanded(child: Container(
        width: double.infinity,
        decoration: BoxDecoration(color: lime, borderRadius: BorderRadius.circular(15)),
        child: Center(child: Text(p.emoji, style: const TextStyle(fontSize: 55))),
      )),
      const SizedBox(height: 9),
      Text(p.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
      Text(p.farm, style: const TextStyle(color: Colors.grey, fontSize: 12)),
      const SizedBox(height: 5),
      Row(children: [
        Text('${p.price.toStringAsFixed(0)} ج.م', style: const TextStyle(color: green, fontWeight: FontWeight.w900)),
        Text(' / ${p.unit}', style: const TextStyle(fontSize: 11, color: Colors.grey)),
        const Spacer(),
        IconButton.filledTonal(
          onPressed: () => setState(() => cart[p] = (cart[p] ?? 0) + 1),
          icon: const Icon(Icons.add, size: 18),
          visualDensity: VisualDensity.compact,
        ),
      ]),
    ]),
  );

  Widget farmerBody() => ListView(padding: const EdgeInsets.all(18), children: [
    Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: lime, borderRadius: BorderRadius.circular(22)),
      child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(Icons.agriculture, color: green, size: 40),
        SizedBox(height: 10),
        Text('لوحة المزارع', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold, color: ink)),
        Text('اعرض محصولك ووصل لعملاء جدد', style: TextStyle(color: ink)),
      ]),
    ),
    const SizedBox(height: 18),
    FilledButton.icon(onPressed: addProduct, icon: const Icon(Icons.add), label: const Text('إضافة منتج جديد')),
    const SizedBox(height: 18),
    const Text('المنتجات المعروضة', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
    ...products.map((p) => ListTile(
      leading: Text(p.emoji, style: const TextStyle(fontSize: 30)),
      title: Text(p.name),
      subtitle: Text('${p.price} ج.م / ${p.unit}'),
      trailing: const Icon(Icons.eco_outlined),
    )),
  ]);

  void addProduct() {
    final name = TextEditingController();
    final price = TextEditingController();
    showDialog(context: context, builder: (dialogContext) => AlertDialog(
      title: const Text('إضافة منتج'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم المنتج')),
        TextField(controller: price, keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'السعر بالجنيه')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إلغاء')),
        FilledButton(onPressed: () {
          final value = double.tryParse(price.text);
          if (name.text.trim().isNotEmpty && value != null && value > 0) {
            setState(() => products.add(Product(name.text.trim(), 'مزرعتي', value, 'كيلو', '🌱', 'خضروات')));
            Navigator.pop(dialogContext);
          }
        }, child: const Text('حفظ')),
      ],
    ));
  }

  Widget cartBody() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('سلة مشترياتك', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: ink)),
    const SizedBox(height: 12),
    if (cart.isEmpty)
      const Padding(padding: EdgeInsets.all(35), child: Center(child: Text('السلة فارغة — أضف منتجات من السوق'))),
    ...cart.entries.map((e) => Card(
      color: Colors.white,
      child: ListTile(
        leading: Text(e.key.emoji, style: const TextStyle(fontSize: 30)),
        title: Text(e.key.name),
        subtitle: Text('${e.key.price} ج.م × ${e.value}'),
        trailing: IconButton(
          icon: const Icon(Icons.remove_circle_outline),
          onPressed: () => setState(() {
            if (e.value <= 1) {
              cart.remove(e.key);
            } else {
              cart[e.key] = e.value - 1;
            }
          }),
        ),
      ),
    )),
    const SizedBox(height: 12),
    Text('الإجمالي المبدئي: ${total.toStringAsFixed(2)} ج.م',
      style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    FilledButton(
      onPressed: cart.isEmpty ? null : () => showDialog(context: context, builder: (dialogContext) => AlertDialog(
        title: const Text('تأكيد مبدئي'),
        content: const Text('هذه نسخة تجريبية. ربط الطلبات والدفع سيتم عند إعداد قاعدة البيانات.'),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('تمام'))],
      )),
      child: const Text('إتمام الطلب'),
    ),
  ]);
}
